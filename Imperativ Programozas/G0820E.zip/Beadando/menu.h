#ifndef MENU_H
#define MENU_H

int showMainMenu(void);
void userGuide(void);

#endif // MENU_H
